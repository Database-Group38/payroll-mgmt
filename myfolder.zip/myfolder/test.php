<?php


    $arr=array("Zafir"=>"Lahore", "Sabahat"=>"karachi");
    $arr["Zafir"];

    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'demo_db';

    $conn = mysqli_connect($servername, $username, $password, $dbname);


    if ($conn==false) {
        echo "Connection Failed";
    } else {

        $sql = "SELECT * FROM `users`";

        $result = mysqli_query($conn,$sql);

        while ($row=mysqli_fetch_assoc($result)) {
            echo $row['user_id'] . ' ';
            echo $row['firstname'] . ' ';
            echo $row['lastname'] . ' ';
            echo $row['age'] . ' ';
            echo $row['gender'] . ' ';
            echo $row['password'] . ' ';

            echo "<br>";
        }

    }

    mysqli_close($conn);

?>