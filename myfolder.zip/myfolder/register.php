<?php

$firstname=$_GET['firstname'];
$lastname=$_GET['lastname'];
$gender = $_GET['gender'];
$age = $_GET['age'];
$password1 = $_GET['password1'];
$password2 = $_GET['password2'];

if ($password1!=$password2) {
    echo "Write the same password you fool.";
    header('Location:index.php?passwordFailure=1');
} else {

    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'demo_db';

    $conn = mysqli_connect($servername, $username, $password, $dbname);


    if ($conn==false) {
        echo "Connection Failed";
    }
    
    //do anything to the database, you have access
    
    $sql = "INSERT INTO `users` (`firstname`, `lastname`, `age`, `gender`, `password`) VALUES ('$firstname','$lastname',$age,'$gender','$password1')";
    
    
    if (mysqli_query($conn, $sql)) {
        echo "Query Successful";
    } else {
        echo "Query failed";
    }
    

    mysqli_close($conn);
}




?>
