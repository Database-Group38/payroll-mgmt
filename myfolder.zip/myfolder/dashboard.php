<?php
    session_start();
    if( isset($_SESSION['login'])==false ) {
        header('Location:login.html');
    }
    session_destroy();
?>


<h1>Welcome My Friend</h1>


