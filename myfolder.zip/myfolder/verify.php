<?php


    $userfirstname=$_GET['firstname'];
    $userpassword=$_GET['password'];

    $servername = 'localhost';
    $username = 'root';
    $password = '';
    $dbname = 'demo_db';

    $conn = mysqli_connect($servername, $username, $password, $dbname);


    if ($conn==false) {
        echo "Connection Failed";
    } else {

        $sql = "SELECT `user_id` FROM `users` WHERE `firstname`='$userfirstname' AND `password`='$userpassword'";

        $result = mysqli_query($conn,$sql);

        if(mysqli_num_rows($result)==0) {
            echo "Wrong credentials.";
        } else {

            session_start();
            $_SESSION['login']=1;

            header('Location:dashboard.php');
        }
    }

    mysqli_close($conn);
?>