<!DOCTYPE html>
<html>

<head>
    <title>Sign Up Form</title>
</head>

<body>

    <?php
        if (isset( $_GET['passwordFailure']) ) {
            echo "<p>Enter the same password please.</p>";
        }
    ?>
    <form action="register.php" method="get">
        <input type="text" name="firstname" placeholder="Enter first name">
        <input type="text" name="lastname" placeholder="Enter last name">
    <br>
    

        <select name="gender">
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="nonbinary">Non-binary</option>
            <option value="na">Prefer not to say</option>
        </select>

        <br>

        <input type="number" name="age" placeholder="Enter Age">
        <br>
        <input type="password" name="password1" placeholder="Enter password">
        <input type="password" name="password2" placeholder="Enter password again">
        <input type="submit">
    </form>

</body>
</html>